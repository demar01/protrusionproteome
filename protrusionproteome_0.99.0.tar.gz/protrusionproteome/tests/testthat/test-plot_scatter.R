context(" plot_scatter ")
data("prot.raw")
test_that("plot_scatter throws error without valid input", {
  expect_error(plot_scatter("se", 1, 2, "HIST", 'orange', 4, 4))
  expect_error(plot_scatter(se, "1", 2, "HIST", 'orange', 4, 4))
  expect_error(plot_scatter(se, 1, 2, HIST, 'orange', 4, 4))
  expect_error(plot_scatter(se, 1, 2, "HIST", orange, 4, 4))
  expect_error(plot_scatter(se, "1", 2, "HIST", 'orange', 4, 4))
  expect_error(plot_scatter(se, 1, 2, "HIST", 'orange', "4", 4))
  expect_error(plot_scatter(se, 1, 2, "HIST", 'orange', 4, '4'))
})

test_that("plot_scatter returns a ggplot object", {
  expect_is(plot_scatter(se, 1, 2, "HIST", 'orange', 4, 4), "ggplot")
})


test_that("filter_MaxQuant returns a data.frame", {
  expect_is(filter_MaxQuant(test_data, c("Reverse", "Potential.contaminant")), "data.frame")
  expect_is(filter_MaxQuant(test_data, "Reverse"), "data.frame")
})
