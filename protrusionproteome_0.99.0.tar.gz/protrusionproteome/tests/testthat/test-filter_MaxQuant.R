context("filter_MaxQuant ")

data("prot.raw")
data <- prot.raw
test_that("filter_MaxQuant throws error without valid input", {
  expect_error(filter_MaxQuant("data",  c("Reverse", "Potential.contaminant","Only.identified.by.site")))
  expect_error(filter_MaxQuant(data, Only.identified.by.site))
 })

test_that("filter_MaxQuant returns a data.frame", {
  expect_type(filter_MaxQuant(data, c("Reverse", "Potential.contaminant","Only.identified.by.site")), "list")
})
