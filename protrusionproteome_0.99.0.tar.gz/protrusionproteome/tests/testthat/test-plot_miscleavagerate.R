context("plot_miscleavagerate ")

data("peptides.raw")
pepdata <- peptides.raw
test_that("plot_miscleavagerate throws error without valid input", {
  expect_error(plot_miscleavagerate("pepdata"))
})
test_that("plot_miscleavagerate returns a ggplot object", {
  expect_type(plot_miscleavagerate("pepdata"), "ggplot")
})
