library(testthat)
library(protrusionproteome)

test_check("protrusionproteome")
