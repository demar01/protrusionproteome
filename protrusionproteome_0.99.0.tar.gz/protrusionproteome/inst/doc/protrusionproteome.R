## ----required packages, echo = FALSE, warning=FALSE, results="hide"-----------
suppressPackageStartupMessages({
  library("BiocStyle")
  library("protrusionproteome")
  library(knitr)
  library(dplyr)
  library(lubridate)
  library(tidyverse)
})

## ----install, eval = FALSE----------------------------------------------------
#  if (!requireNamespace("BiocManager", quietly=TRUE))
#      install.packages("BiocManager")
#  BiocManager::install("protrusionproteome")
#  library("protrusionproteome")

## ----setup, message=FALSE-----------------------------------------------------
library(protrusionproteome)
library(dplyr)
library(SummarizedExperiment)
library(lubridate)


## ----load-data-peptides-------------------------------------------------------
# Peptides data is provided with the package
data("peptides.raw")
pepdata <- peptides.raw

## ----plot-miscleavages--------------------------------------------------------
# Stacked barplot of trypsin miscleavages
plot_miscleavagerate(pepdata)

## ----load-data-evidence-------------------------------------------------------
#Evidence data is provided with the package
data("evidence.raw")
evidencedata <- evidence.raw

## ----plot-labelingefficiency--------------------------------------------------
 plot_labelingefficiency(evidencedata)

## ----load-data----------------------------------------------------------------
# The data is provided with the package
data("prot.raw")
data <- prot.raw

## ----dim-data-----------------------------------------------------------------
dim(data)

## ----proteins-filtered--------------------------------------------------------
proteins_filtered <- filter_MaxQuant(data,
    tofilter= c("Reverse" , "Potential.contaminant" ,"Only.identified.by.site"))

## ----dim-proteins-filtered----------------------------------------------------
dim(proteins_filtered)

## ----cheking-duplicated-Gene-names--------------------------------------------
# Are Gene.names primary key to this table?
proteins_filtered %>% group_by(Gene.names) %>% summarize(count= n()) %>% 
  arrange(desc( count)) %>% filter( count > 1)

## ----make-unique--------------------------------------------------------------
data_unique <- make_unique(proteins_filtered, "Gene.names", "Protein.IDs", delim = ";")

## ----data-unique-cheking-duplicated-Gene-names--------------------------------
data_unique %>% group_by(name) %>% tally() %>% filter(n > 1) %>% nrow()

## ----kable-experiment, fig.cap = "Intensities and corresponding experiment"----
columns_positions<-str_which(colnames(data_unique),"Reporter.intensity.corrected.(\\d)+.(\\d)")
intensities <- colnames(data_unique)[str_which(colnames(data_unique),"Reporter.intensity.corrected.(\\d)+.(\\d)")]
time_unit=30
time_span=c(1,2,4,8,16)
experiment <- str_c(minute(rep(minutes(x = time_unit) *time_span,each=2)),c("body","prot"),sep="_")
knitr::kable(tibble(intensities,experiment))

## ----create-TMT-se, warning=FALSE, message=FALSE------------------------------
# Generate a SummarizedExperiment object using using file information and user input
columns_positions<-str_which(colnames(data_unique),"Reporter.intensity.corrected.(\\d)+.(\\d)")
se <- make_TMT_se(data_unique,columns_positions,intensities,time_unit=30,
time_span=c(1,2,4,8,16), numerator= "prot", denominator= "body", sep = "_")

# Let's have a look at the SummarizedExperiment object
se

## ----colData------------------------------------------------------------------
SummarizedExperiment::colData(se)

## ----plot-scatter,  warning=FALSE---------------------------------------------
plot_scatter(se, 1, 2, "HIST", 'orange', 4, 4)

## ----enrichment-tibble,  warning=FALSE----------------------------------------
enrichment_table <- enrich_1D(se,timepoint= 5,
                               dbs = "GO_Molecular_Function_2018",
                              number_dbs=1)


## ----session_info, echo = FALSE-----------------------------------------------
sessionInfo()

